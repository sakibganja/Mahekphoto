export const Card = ({ children }) => <div className='p-4 rounded-2xl shadow-xl bg-white'>{children}</div>;
export const CardContent = ({ children }) => <div>{children}</div>;